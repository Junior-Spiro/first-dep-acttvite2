import 'dart:io';

import 'package:uuid/uuid.dart';

class Endroit {
  final String id;
  final String nom;
  final File? image; //peut être null
  //créer une constante instance de la classe Uuid
  static const uuid = Uuid();

  Endroit({required this.nom, this.image}) : id = uuid.v4();
}
