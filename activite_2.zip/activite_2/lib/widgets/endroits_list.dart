import 'package:activite_2/modele/endroit.dart';
import 'package:activite_2/vue/endroit_detail.dart';
import 'package:flutter/material.dart';

class EndroitsList extends StatelessWidget {
  final List<Endroit> endroits;
  const EndroitsList({super.key, required this.endroits});

  @override
  Widget build(BuildContext context) {
    if (endroits.isEmpty) {
      // Si la liste est vide, on affiche un texte centré
      return const Center(
        child: Text("Il n'y a pas d'endroits favoris pour le moment."),
      );
    }
    // Sinon liste déroulante avec ListView.builder
    return ListView.builder(
      itemCount: endroits.length,
      itemBuilder: (context, index) {
        final endroit = endroits[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundImage: endroit.image != null
                ? FileImage(endroit.image!)
                : null,
            child: endroit.image == null ? const Icon(Icons.place) : null,
          ),
          title: Text(endroit.nom),
          onTap: () {
            //naviguation vers l'ecran de détail de l'endroit
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => EndroitDetail(endroit: endroit),
              ),
            );
          },
        );
      },
    );
  }
}
