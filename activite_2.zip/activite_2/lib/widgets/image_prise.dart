import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ImagePrise extends StatefulWidget {
  final void Function(File image) onPhotoSelectionne;
  const ImagePrise({super.key, required this.onPhotoSelectionne});

  @override
  State<ImagePrise> createState() => _ImagePriseState();
}

class _ImagePriseState extends State<ImagePrise> {
  File? _pickedImage;

  Future<void> prendrePhoto() async {
    final imagePicker = ImagePicker();
    final photoPrise = await imagePicker.pickImage(
      source: ImageSource.camera,
      maxWidth: 600,
    );
    if (photoPrise == null) return;
    //variable pour stocker l'objet File
    final file = File(photoPrise.path);
    setState(() => _pickedImage = file);
    widget.onPhotoSelectionne(file);
  }

  @override
  Widget build(BuildContext context) {
    if (_pickedImage == null) {
      return TextButton.icon(
        onPressed: prendrePhoto,
        label: Text(
          'Prendre photo',
          style: TextStyle(
            color: Colors.blueGrey[800],
            fontWeight: FontWeight.bold,
          ),
        ),
        icon: const Icon(Icons.camera, color: Colors.blueAccent),
      );
    }

    return GestureDetector(
      onTap: prendrePhoto,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: AspectRatio(
          aspectRatio: 4 / 3,
          child: Image.file(_pickedImage!, fit: BoxFit.cover),
        ),
      ),
    );
  }
}
