import 'package:activite_2/providers/endroits_utilisateurs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:activite_2/vue/ajout_endroit.dart';
import 'package:activite_2/widgets/endroits_list.dart';

//Affichage de la liste des endroits préférésde l'utilisateur

class EndroitsInterface extends ConsumerWidget {
  const EndroitsInterface({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    //ceci crée un listener des changements des données
    final endroitsUtilisateur = ref.watch(endroitsprovider);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text(
          "Mes endroits préférés",
          style: TextStyle(fontSize: MediaQuery.of(context).size.width * 0.05),
        ),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (context) => AjoutEndroit()));
            },
            icon: const Icon(Icons.add, size: 40, color: Colors.blueGrey),
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsetsGeometry.all(16),
        child: EndroitsList(endroits: endroitsUtilisateur),
      ),
    );
  }
}
