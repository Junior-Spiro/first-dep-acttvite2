import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'widgets/endroits_interface.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(ProviderScope(child: MonApplication()));
}

class MonApplication extends StatelessWidget {
  const MonApplication({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Application d'endroit",
      home: EndroitsInterface(),
    );
  }
}
