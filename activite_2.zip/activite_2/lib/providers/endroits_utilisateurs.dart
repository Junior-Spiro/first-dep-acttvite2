import 'dart:io';

import 'package:activite_2/modele/endroit.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

//----Cette classe est utilisée pour gérer l'état sous forme
//d'une liste d'objets Endroit

class EndroitsUtilisateurs extends StateNotifier<List<Endroit>> {
  //constructeur;l'état initial est une liste vide
  EndroitsUtilisateurs() : super(const []);

  // Ajoute un lieu en tête de liste
  void ajouteEndroit(String nom, File? image) {
    final newEndroit = Endroit(nom: nom, image: image);
    state = [
      newEndroit,
      ...state,
    ]; // Préfixe pour afficher le plus récent en haut
  }

  // Ajoute un lieu en tête de liste
  void supprimer(String id) {
    state = state.where((e) => e.id != id).toList();
  }

  // Réinitialise la liste
  void vider() {
    state = [];
  }
}

//création d'un fournisseur
//ce provider utilise endroits utilisateur et une liste d'endroits
final endroitsprovider =
    StateNotifierProvider<EndroitsUtilisateurs, List<Endroit>>(
      (ref) => EndroitsUtilisateurs(),
    );
