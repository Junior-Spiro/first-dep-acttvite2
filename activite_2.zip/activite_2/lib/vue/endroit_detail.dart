import 'package:activite_2/modele/endroit.dart';
import 'package:flutter/material.dart';

class EndroitDetail extends StatelessWidget {
  final Endroit endroit;
  const EndroitDetail({super.key, required this.endroit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.amber, title: Text(endroit.nom)),
      body: Column(
        children: [
          if (endroit.image != null)
            Image.file(
              endroit.image!,
              height: 600,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              endroit.nom,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}
