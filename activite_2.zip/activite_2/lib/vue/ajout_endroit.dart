import 'dart:io';

import 'package:activite_2/providers/endroits_utilisateurs.dart';
import 'package:activite_2/widgets/image_prise.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AjoutEndroit extends ConsumerStatefulWidget {
  const AjoutEndroit({super.key});

  @override
  ConsumerState<AjoutEndroit> createState() => _AjoutEndroitState();
}

class _AjoutEndroitState extends ConsumerState<AjoutEndroit> {
  final TextEditingController _nomController = TextEditingController();
  File? _pickedImage; // Stocke l’image sélectionnée

  void _onPhotoSelectionne(File image) {
    setState(() => _pickedImage = image);
  }

  void _enregistreEndroit() {
    final nom = _nomController.text;
    if (nom.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Veuillez saisir un nom pour l'endroit")),
      );
      return;
    }
    ref.read(endroitsprovider.notifier).ajouteEndroit(nom, _pickedImage);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.amber,
          title: Text(
            "Ajout d'un nouveau endroit",
            style: TextStyle(
              fontSize: MediaQuery.of(context).size.width * 0.05,
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _nomController,
                decoration: const InputDecoration(
                  labelText: "Nom de l'endroit",
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              ImagePrise(onPhotoSelectionne: _onPhotoSelectionne),
              SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _enregistreEndroit,
                icon: const Icon(Icons.save, size: 20, color: Colors.blueGrey),
                label: Text(
                  'Ajouter un nouveau endroit',
                  style: TextStyle(color: Colors.blueGrey[700]),
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
